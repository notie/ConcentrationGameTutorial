//
//  AppDelegate.h
//  ConcentrationTutorial
//
//  Created by Todd Bernhard on 9/2/16.
//  Copyright © 2016 No Tie. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

